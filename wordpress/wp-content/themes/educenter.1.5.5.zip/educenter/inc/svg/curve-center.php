<svg class="svg-curve-center" fill="#FF0000" width="100%" height="50" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 100 100">
    <path d="M0 100 C40 0 60 0 100 100 Z"></path>
</svg>