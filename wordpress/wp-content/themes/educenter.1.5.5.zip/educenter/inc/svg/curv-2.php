<svg style="fill:#cf2e2e" viewBox="0 0 1000 100" preserveAspectRatio="none">
    <path style="opacity:0.33" d="M0 95L1000 0v100H0v-5z"></path>
    <path style="opacity:0.66" d="M0 95l1000-67.944V100H0v-5z"></path>
    <path d="M0 95l1000-40.887V100H0v-5z"></path>
</svg>