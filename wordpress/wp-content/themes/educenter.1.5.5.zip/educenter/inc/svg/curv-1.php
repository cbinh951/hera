<svg style="fill:#cf2e2e" viewBox="0 0 1000 100" preserveAspectRatio="none">
    <path d="M1000,0l-500,98l-500,-98l0,100l1000,0l0,-100Z" style="opacity:0.4"></path>
    <path d="M1000,20l-500,78l-500,-78l0,80l1000,0l0,-80Z"></path>
</svg>