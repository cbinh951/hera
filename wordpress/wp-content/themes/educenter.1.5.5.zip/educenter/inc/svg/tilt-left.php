<svg fill="#FF0000" width="100%" height="100%" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 4 0.266661">
    <polygon points="4,0 4,0.266661 -0,0.266661 "></polygon>
</svg>